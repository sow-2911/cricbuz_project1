import streamlit as st

def show():
    st.title("🏏 Cricbuzz LiveStats")
    
    st.markdown("""
    ### 📌 Project Overview
    Cricbuzz LiveStats is a **cricket analytics platform** that provides:
    - 📡 **Live match updates**
    - 📊 **Player performance analytics**
    - 🗂 **SQL-driven analytics & queries**
    - ✍️ **CRUD operations for player and match data**
    """)

    st.markdown("---")

    st.markdown("""
    ### 🛠 Tools & Technologies
    - **Frontend**: Streamlit  
    - **Backend**: Python, SQLAlchemy  
    - **Database**: PostgreSQL / MySQL (configure via `.env`)  
    - **Deployment**: Streamlit Cloud / Local Server  
    """)

    st.markdown("---")

    st.markdown("""
    ### 📖 Instructions
    1. Configure your **`.env`** file with `DATABASE_URL`.  
    2. Use the **sidebar** to navigate between pages.  
    3. Explore **LiveStats**, **Player Analytics**, and **Database CRUD**.  
    """)

    st.info("ℹ️ Use the sidebar to switch between app sections.")

    st.markdown("---")

    st.markdown("""
    ### 📂 Project Resources
    - 📘 [Project Documentation](https://github.com/your-username/your-repo/blob/main/README.md)  
    - 📁 [Folder Structure Info](https://your-github-repo-link.com)  
    """)