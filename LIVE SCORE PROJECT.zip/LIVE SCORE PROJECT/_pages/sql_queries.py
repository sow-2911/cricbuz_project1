import streamlit as st
from utils.db_connection import get_db_session
from sqlalchemy import text
import pandas as pd

def run_query(sql, params=None):
    with get_db_session() as session:
        result = session.execute(text(sql), params or {})
        cols = result.keys()
        rows = result.fetchall()
    return pd.DataFrame(rows, columns=cols)

def show():
    st.header("Run SQL Queries")
    uploaded = st.file_uploader("Or paste a SQL query file")
    st.markdown("**Sample queries**")
    sample_q = st.selectbox("Select a sample query", ["Top run scorers (ODI)","Wins per team","Highest score per format"])
    sample_map = {
        "Top run scorers (ODI)": "SELECT p.full_name, pa.runs FROM player_aggregates pa JOIN players p ON pa.player_id=p.player_id WHERE pa.format='ODI' ORDER BY pa.runs DESC LIMIT 10",
        "Wins per team": "SELECT t.name, COUNT(*) as wins FROM matches m JOIN teams t ON m.winner_team_id = t.team_id GROUP BY t.name ORDER BY wins DESC",
        "Highest score per format": "SELECT format, MAX(high_score) AS highest FROM player_aggregates GROUP BY format"
    }
    if st.button("Run sample"):
        df = run_query(sample_map[sample_q])
        st.dataframe(df)
    st.markdown("Run custom SQL (READ only):")
    sql_input = st.text_area("SQL", height=150)
    if st.button("Run SQL"):
        try:
            res = run_query(sql_input)
            st.dataframe(res)
        except Exception as e:
            st.error(str(e))