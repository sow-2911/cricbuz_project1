# pages/top_stats.py
import streamlit as st
import pandas as pd
import requests
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Top Player Stats", layout="wide")

# API configuration
API_KEY = "9b3a58d5a2mshe2317d2b9034630p1d41cbjsn90db418e9ce3"
API_HOST = "cricbuzz-cricket.p.rapidapi.com"
HEADERS = {
    "x-rapidapi-key": API_KEY,
    "x-rapidapi-host": API_HOST
}

def fetch_api_data(endpoint, params=None):
    """Fetch data from Cricbuzz API"""
    url = f"https://{API_HOST}/{endpoint}"
    try:
        response = requests.get(url, headers=HEADERS, params=params)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"API Error: {e}")
        return None

def get_series_list():
    """Get list of available series"""
    try:
        # Get series list from the correct endpoint
        data = fetch_api_data("series/v1/international")
        
        if data and "seriesMapProto" in data:
            series_list = []
            for month_data in data["seriesMapProto"]:
                if "series" in month_data:
                    for series in month_data["series"]:
                        series_list.append({
                            "id": series.get("id", 0),
                            "name": series.get("name", "Unknown Series"),
                            "startDt": series.get("startDt", ""),
                            "endDt": series.get("endDt", "")
                        })
            return series_list
        return []
    except Exception as e:
        st.error(f"Error fetching series: {e}")
        # Fallback to a default series if API fails
        return [{"id": 3641, "name": "New Zealand tour of England, 2022", "startDt": "1654128000000", "endDt": "1656288000000"}]

def get_series_stats(series_id, stat_type="mostRuns"):
    """Get statistics for a series"""
    endpoint = f"stats/v1/series/{series_id}"
    params = {"statsType": stat_type}
    
    data = fetch_api_data(endpoint, params)
    if data and "odiStatsList" in data:
        return data["odiStatsList"]
    return None

def process_batting_stats(stats_data):
    """Process batting statistics into DataFrame"""
    if not stats_data or "values" not in stats_data:
        return pd.DataFrame()
    
    headers = stats_data.get("headers", [])
    values = stats_data.get("values", [])
    
    rows = []
    for player_data in values:
        player_values = player_data.get("values", [])
        if len(player_values) >= 5:  # Ensure we have at least basic data
            rows.append({
                "Player ID": player_values[0] if len(player_values) > 0 else "N/A",
                "Player": player_values[1] if len(player_values) > 1 else "N/A",
                "Matches": int(player_values[2]) if len(player_values) > 2 and player_values[2].isdigit() else 0,
                "Innings": int(player_values[3]) if len(player_values) > 3 and player_values[3].isdigit() else 0,
                "Runs": int(player_values[4]) if len(player_values) > 4 and player_values[4].isdigit() else 0,
                "Average": float(player_values[5]) if len(player_values) > 5 and player_values[5].replace('.', '').isdigit() else 0.0,
            })
    
    return pd.DataFrame(rows)

def process_bowling_stats(stats_data):
    """Process bowling statistics into DataFrame"""
    if not stats_data or "values" not in stats_data:
        return pd.DataFrame()
    
    headers = stats_data.get("headers", [])
    values = stats_data.get("values", [])
    
    rows = []
    for player_data in values:
        player_values = player_data.get("values", [])
        if len(player_values) >= 5:  # Ensure we have at least basic data
            rows.append({
                "Player ID": player_values[0] if len(player_values) > 0 else "N/A",
                "Player": player_values[1] if len(player_values) > 1 else "N/A",
                "Matches": int(player_values[2]) if len(player_values) > 2 and player_values[2].isdigit() else 0,
                "Overs": player_values[3] if len(player_values) > 3 else "0",
                "Wickets": int(player_values[4]) if len(player_values) > 4 and player_values[4].isdigit() else 0,
                "Average": float(player_values[5]) if len(player_values) > 5 and player_values[5].replace('.', '').isdigit() else 0.0,
            })
    
    return pd.DataFrame(rows)

def create_batting_charts(df):
    """Create visualizations for batting stats"""
    if df.empty:
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Top run scorers
        top_scorers = df.nlargest(10, "Runs")
        fig1 = px.bar(top_scorers, x="Player", y="Runs", 
                     title="Top Run Scorers", color="Runs",
                     color_continuous_scale="Viridis")
        st.plotly_chart(fig1, use_container_width=True)
    
    with col2:
        # Best averages (min 5 innings)
        qualified = df[df["Innings"] >= 5]
        if not qualified.empty:
            best_avg = qualified.nlargest(10, "Average")
            fig2 = px.bar(best_avg, x="Player", y="Average", 
                         title="Best Batting Average (min 5 innings)", color="Average",
                         color_continuous_scale="Plasma")
            st.plotly_chart(fig2, use_container_width=True)

def create_bowling_charts(df):
    """Create visualizations for bowling stats"""
    if df.empty:
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Most wickets
        top_wickets = df.nlargest(10, "Wickets")
        fig1 = px.bar(top_wickets, x="Player", y="Wickets", 
                     title="Most Wickets", color="Wickets",
                     color_continuous_scale="Viridis")
        st.plotly_chart(fig1, use_container_width=True)
    
    with col2:
        # Best averages (min 20 wickets)
        qualified = df[df["Wickets"] >= 20]
        if not qualified.empty:
            best_avg = qualified.nsmallest(10, "Average")
            fig2 = px.bar(best_avg, x="Player", y="Average", 
                         title="Best Bowling Average (min 20 wickets)", color="Average",
                         color_continuous_scale="Plasma")
            st.plotly_chart(fig2, use_container_width=True)

def show():
    st.title("🏆 Top Player Statistics")
    
    # Get available series
    series_list = get_series_list()
    
    if not series_list:
        st.warning("No series data available. Please check your API connection.")
        return
    
    # Series selection
    series_options = {s["name"]: s["id"] for s in series_list}
    selected_series = st.selectbox("Select Series", list(series_options.keys()))
    series_id = series_options[selected_series]
    
    # Stat type selection
    stat_tabs = st.tabs(["🏏 Batting Stats", "🎯 Bowling Stats", "ℹ️ Series Info"])
    
    with stat_tabs[0]:
        st.header("Top Batting Performances")
        
        # Fetch batting stats
        batting_stats_data = get_series_stats(series_id, "mostRuns")
        batting_df = process_batting_stats(batting_stats_data)
        
        if not batting_df.empty:
            # Display data and charts
            st.dataframe(batting_df, use_container_width=True)
            create_batting_charts(batting_df)
            
            # Additional insights
            st.subheader("Batting Insights")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                highest_score = batting_df.nlargest(1, "Runs")
                if not highest_score.empty:
                    st.metric("Highest Run Scorer", 
                             f"{highest_score.iloc[0]['Player']}", 
                             f"{int(highest_score.iloc[0]['Runs'])} runs")
            
            with col2:
                best_avg = batting_df[batting_df["Innings"] >= 5].nlargest(1, "Average")
                if not best_avg.empty:
                    st.metric("Best Average", 
                             f"{best_avg.iloc[0]['Player']}", 
                             f"{best_avg.iloc[0]['Average']:.2f}")
            
            with col3:
                most_innings = batting_df.nlargest(1, "Innings")
                if not most_innings.empty:
                    st.metric("Most Innings", 
                             f"{most_innings.iloc[0]['Player']}", 
                             f"{int(most_innings.iloc[0]['Innings'])} innings")
        else:
            st.info("No batting statistics available for this series.")
    
    with stat_tabs[1]:
        st.header("Top Bowling Performances")
        
        # Fetch bowling stats
        bowling_stats_data = get_series_stats(series_id, "mostWickets")
        bowling_df = process_bowling_stats(bowling_stats_data)
        
        if not bowling_df.empty:
            # Display data and charts
            st.dataframe(bowling_df, use_container_width=True)
            create_bowling_charts(bowling_df)
            
            # Additional insights
            st.subheader("Bowling Insights")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                most_wickets = bowling_df.nlargest(1, "Wickets")
                if not most_wickets.empty:
                    st.metric("Most Wickets", 
                             f"{most_wickets.iloc[0]['Player']}", 
                             f"{int(most_wickets.iloc[0]['Wickets'])} wickets")
            
            with col2:
                best_avg = bowling_df[bowling_df["Wickets"] >= 10].nsmallest(1, "Average")
                if not best_avg.empty:
                    st.metric("Best Bowling Average", 
                             f"{best_avg.iloc[0]['Player']}", 
                             f"{best_avg.iloc[0]['Average']:.2f}")
            
            with col3:
                most_matches = bowling_df.nlargest(1, "Matches")
                if not most_matches.empty:
                    st.metric("Most Matches", 
                             f"{most_matches.iloc[0]['Player']}", 
                             f"{int(most_matches.iloc[0]['Matches'])} matches")
        else:
            st.info("No bowling statistics available for this series.")
    
    with stat_tabs[2]:
        st.header("Series Information")
        
        # Display series details
        selected_series_info = next((s for s in series_list if s["id"] == series_id), None)
        
        if selected_series_info:
            st.write(f"**Series Name:** {selected_series_info['name']}")
            st.write(f"**Series ID:** {selected_series_info['id']}")
            
            # Convert timestamp to readable date
            if selected_series_info['startDt']:
                from datetime import datetime
                start_date = datetime.fromtimestamp(int(selected_series_info['startDt']) / 1000)
                st.write(f"**Start Date:** {start_date.strftime('%Y-%m-%d')}")
            
            if selected_series_info['endDt']:
                from datetime import datetime
                end_date = datetime.fromtimestamp(int(selected_series_info['endDt']) / 1000)
                st.write(f"**End Date:** {end_date.strftime('%Y-%m-%d')}")
        
        # Show raw API response for debugging
        with st.expander("View Raw API Response (for debugging)"):
            st.write("Batting Stats API Response:")
            batting_stats_data = get_series_stats(series_id, "mostRuns")
            st.json(batting_stats_data)
            
            st.write("Bowling Stats API Response:")
            bowling_stats_data = get_series_stats(series_id, "mostWickets")
            st.json(bowling_stats_data)
