# utils/cricbuzz_api.py
import requests
import time
from functools import lru_cache

CRICBUZZ_BASE = "https://cricbuzz-cricket.p.rapidapi.com"  # RapidAPI endpoint
RAPIDAPI_KEY = "9b3a58d5a2mshe2317d2b9034630p1d41cbjsn90db418e9ce3"
HEADERS = {
        "x-rapidapi-key": "9b3a58d5a2mshe2317d2b9034630p1d41cbjsn90db418e9ce3",
        "x-rapidapi-host": "cricbuzz-cricket.p.rapidapi.com"
    }

def fetch_json(path, params=None, timeout=10, max_retries=2):
    
    url = f"{CRICBUZZ_BASE}/{path}"
    retries = 0
    while retries <= max_retries:
        try:
            r = requests.get(url, headers=HEADERS, params=params, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except requests.RequestException as e:
            retries += 1
            if retries > max_retries:
                raise
            time.sleep(1 * retries)

# Cache live match list for 5 seconds to avoid hammering
@lru_cache(maxsize=128)
def get_live_matches():
    """
    Returns live matches from Cricbuzz via RapidAPI.
    """
    
    return fetch_json("/matches/v1/live")  # adjust path if needed
