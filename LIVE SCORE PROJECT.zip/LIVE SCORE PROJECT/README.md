DELETE venv FOLDER IN CURRENT DIRECTORY
OPEN TERMINAL RUN FOLLOWING COMMANDS
"""
python -m venv venv
venv\Scripts\activate  # or source venv/bin/activate on Linux
pip install -r requirements.txt # if not work try "Remove-Item -Recurse -Force venv"
streamlit run main.py

"""
install MySQL workbench "https://dev.mysql.com/downloads/file/?id=544662";
replace mysql username and password and databse name in .env file
CREATE DATABASE SCORE;
USE SCORE;; # use DATABASE_NAME
execute db_schema.sql file queries;
execute sample_data.sql queries for data insertion

RUN 25 QUESTIONS IN SQL ANALYTICS TAB
sql_queries.md file available answers